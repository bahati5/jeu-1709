# LE CARTON 47
### L'histoire — version 2, avec ce qu'il faut de FROM et de Game of Thrones

---

## Ce qui change, et pourquoi

La version 1 était un thriller administratif : deux voix, cinq retournements, une enquête propre. Bien ficelée, mais **sans peur et sans perte** — et ce sont exactement les deux choses qui font qu'on regarde FROM et Game of Thrones jusqu'au bout.

Trois ajouts, et ils changent tout :

| Ce qui vient de… | Ce que ça donne |
|---|---|
| **FROM** — une ville avec des règles qu'on doit deviner, et qui punissent | **Une règle absurde et non négociable**, répétée chaque soir. Et des **symboles** au dos de chaque pièce, dont il ne comprendra le système qu'au sixième jour |
| **FROM** — ce qui ne s'explique pas | Trois anomalies que la logique ne couvre pas. Elles ont toutes une explication à la fin, mais pendant six jours **il ne peut pas savoir** s'il enquête ou s'il devient fou |
| **Game of Thrones** — un ensemble, et personne n'est en sécurité | **Cinq correspondants** avec chacun son intérêt. Des alliances qui se retournent. Et une personne qu'il perd **à cause d'une information qu'il lui a donnée** |

> La v1 lui demandait : *qui ment ?*
> La v2 lui demande : *à qui je fais du mal en continuant ?*

---

## La règle

Adèle la lui écrit le premier soir, et la répète chaque soir, dans les mêmes termes. C'est agaçant, puis inquiétant, puis c'est la clé.

> **Le carton 47 ne se consulte qu'entre le coucher et le lever du soleil.**
> **Ce qui en sort la nuit doit y être rentré avant l'aube.**
> **On n'écrit jamais dans le registre. On recopie à côté.**

Elle ne dit jamais pourquoi. Quand il demande, elle change de sujet — c'est la seule chose sur laquelle elle ne répond pas.

**Et la règle a des dents.** Au chapitre 4, il garde une pièce chez lui une nuit de trop. Le lendemain, la pièce est vierge : l'encre a disparu. Il n'en existe plus aucune copie, et l'énigme de ce jour-là devient plus difficile — définitivement. *(Réglable depuis l'admin : tu décides si la sanction est réelle ou seulement racontée.)*

---

## Les symboles

Chaque pièce du carton porte au dos une marque gravée au canif. Sept marques différentes, jamais expliquées.

Il les prendra d'abord pour une numérotation d'archiviste. Au chapitre 6, en les alignant dans l'ordre où il a résolu les pièces, il verra que ce sont **des chiffres écrits à l'envers, dans un système à sept symboles** — et que quelqu'un les a gravés pour qu'on ne puisse les lire qu'après avoir tout résolu.

> Ce n'est pas une énigme obligatoire. C'est une couche pour celui qui regarde. Comme les symboles de FROM : on peut finir sans, mais on ne parle que de ça.

---

## L'ensemble

Cinq personnes lui écrivent. Aucune ne dit toute la vérité, et **aucune ne ment sur tout**.

**ADÈLE MBENG** · 58 ans · archiviste
Phrases complètes, ponctuées, trop polies. **Elle le vouvoie du premier au dernier jour** — le seul détail qui aurait dû l'alerter : on ne vouvoie pas quelqu'un à qui on demande de risquer sa place. Elle ment une fois par jour, jamais sur les faits, toujours sur ses raisons.

**OKOUMÉ** · 61 ans · greffier radié en 2019
Minuscules, sans ponctuation, une ligne à la fois, à des heures impossibles. **Il ne ment jamais — il se tait**, ce qui produit le même effet et c'est là son tour de force.

**RUTH** · 23 ans · stagiaire à la numérisation
Écrit trop, tard, avec des fautes et des vocaux de quarante secondes. Enthousiaste, elle veut aider, elle trouve ça excitant. **C'est elle qu'il va perdre.**

**MME ONDO** · direction des archives
N'écrit que trois fois en huit jours. Courtoise, glaçante, en-tête officiel. Elle veut le carton détruit et ne s'en cache pas : *« Ces documents sont périmés. Leur conservation est une négligence, pas un devoir. »*

**BALEP** · 47 ans · vigile de nuit
Vend ce qu'il voit à qui paie. Il aide au chapitre 4 contre un service. Il vend au chapitre 6. Il n'a rien contre personne — **c'est le personnage le plus honnête du lot, et c'est lui qui fait le plus de dégâts.**

---

## Les huit chapitres

### 1 · mercredi 10 — « Vous êtes le seul dont j'ai le contact »

**23h47.** Un numéro inconnu. Adèle se présente, explique le carton 47, dit qu'elle ne peut rien envoyer directement. Elle le teste avec un vieux dossier de 1994 : sept voisins, deux menteurs.

Puis, en post-scriptum, la règle. Sans explication.

*(sept dépositions → `VENDREDI`)*

### 2 · jeudi 11 — L'autre numéro

Adèle envoie un objet saisi chez un faussaire : certificat impeccable, registre qui dit le contraire. *« Apprenez à ne pas croire un papier tamponné. Vous en verrez d'autres. »*

**04h12 :** `n'ouvrez pas ce qu'elle vous envoie`

**Et un troisième message, 09h30 :** Ruth. Elle a vu passer son nom dans le journal des consultations. Elle propose de l'aider — elle a accès au scanner.

> **Premier retournement, et il ne le voit pas :** personne n'a dit à Okoumé qu'Adèle lui écrivait.

*(le faux certificat → `1999`)*

### 3 · vendredi 12 — Le silence, et le carnet

Adèle n'écrit pas de la journée. **Okoumé envoie la pièce à sa place** — et elle est mieux préparée que les siennes.

> `un carnet qui ne s'ouvre pas est un carnet qui attend qu'on le lui demande correctement`
> `elle vous ment sur un point. un seul. je ne vous dirai pas lequel, vous ne me croiriez pas et vous auriez raison`

Ruth, le soir : *« jai retrouvé le cliché de 1999 dans le carton !! il y a 6 personnes dessus mais le registre de garde en liste 5 😭 »*

**Première anomalie.** Personne n'expliquera jamais qui est la sixième.

*(le carnet fermé → `SEPTEMBRE`)*

### 4 · samedi 13 — Ce qui a été effacé, et ce qui s'efface

Il remonte le fil : **un horodatage sans message.** Adèle a écrit le 12 à 09h04. Supprimé avant qu'il l'ouvre.

> **Deuxième retournement.** Ce n'est pas une surveillance extérieure. Quelqu'un a la main sur le canal.

Balep lui propose un marché : il peut photographier le carton pendant sa ronde, contre un service. Il accepte.

**Et c'est le soir où il garde une pièce trop longtemps.** Au matin, elle est vierge.

> **Deuxième anomalie.** L'encre a disparu. Il n'y a pas d'explication rationnelle, et personne ne lui en propose.

*(les relevés maquillés → `DU 12 AU 19`)*

### 5 · dimanche 14 — L'accusation, et le silence de Ruth

Adèle, froide : *« Pourquoi lui avez-vous parlé du carton 47 ? Je ne l'avais dit qu'à vous. »*

Il n'a rien dit. Ils comparent, et comprennent : **depuis trois jours, Okoumé écrit à Adèle en se faisant passer pour lui.**

> **Troisième retournement.** Il n'a pas seulement été surveillé — **il a été employé.** Tout ce qu'il trouvait, Okoumé le recevait le soir même, signé de son nom.

**Et Ruth ne répond plus.** Son dernier message date de 23h14 la veille : *« attends je crois quil y a quelquun »*

*(cinq déclarations, un imposteur → et ce jour-là ce n'est plus une métaphore)*

### 6 · lundi 15 — Le dossier, et ce qu'il a fait

Il force le scellé. Dossier personnel d'Okoumé, conseil de discipline 2019 :

> *Radié pour refus caractérisé d'exécuter l'ordre de destruction du carton 47.*

> **Quatrième retournement.** L'homme qui le freinait depuis six jours n'est pas l'ennemi. C'est le seul, depuis six ans, à protéger quelqu'un.

Puis le message de Mme Ondo, en-tête officiel, deux lignes :

> *Mlle Ruth Ekomi a été mise à pied à titre conservatoire le 14 septembre, à la suite d'un accès non autorisé au fonds 47. Nous vous saurions gré de cesser toute sollicitation.*

**C'est lui qui lui avait demandé de scanner le cliché.**

Et Balep, le même soir, laconique : *« la dame m'a demandé qui venait la nuit. j'ai dit. désolé chef. »*

> **Ce jour-là, il ne perd pas une manche. Il perd quelqu'un.** Ruth n'est pas morte, elle est renvoyée à 23 ans pour l'avoir aidé, et il n'a aucun moyen de réparer ça. **C'est la première fois que le jeu lui coûte.**

Okoumé, à 03h50 :
> `vous êtes allé trop loin maintenant`
> `si vous vous arrêtez là ils reprendront le dossier et le brûleront et elle sera tranquille`
> `si vous continuez vous la trouverez`
> `je ne vous aiderai plus mais je ne vous empêcherai plus`
> `choisissez vite il reste deux jours`

**Elle.**

*(le scellé → `561`)*

### 7 · mardi 16 — Qui tenait la clé

Cinq personnes de garde la nuit du 16 au 17 septembre 1999. Une seule clé du registre.

> **ADÈLE MBENG**

> **Cinquième retournement.** Elle n'a pas découvert cet acte en numérisant il y a six mois. **Elle l'a écrit il y a vingt-sept ans.** Elle a passé six mois à chercher quelqu'un capable de remonter jusqu'à elle — parce qu'une confession, on la croit ou on ne la croit pas ; une preuve, non.

Elle ne nie pas :
> *Oui. Je vous ai fait travailler six jours pour arriver à moi. C'était le seul moyen que ça compte.*
> *Pour Ruth, je suis désolée. Je ne pensais pas qu'elle irait aussi vite.*

**Et les sept symboles s'alignent.** Ce ne sont pas des numéros d'archivage : c'est une date, gravée à l'envers, au canif, par quelqu'un qui savait qu'on ne la lirait qu'à la fin.

*(la grille → `04H10`)*

### 8 · mercredi 17, 06h00 — Pourquoi

> *La maternité Sainte-Odile a été fermée par arrêté n° 561, du 12 au 19 septembre 1999. Huit jours. Un bâtiment administrativement mort.*
>
> *Un enfant y est né quand même. Je l'ai mis au monde moi-même, il n'y avait personne d'autre.*
>
> *Un enfant sans déclaration n'a pas de nom. Pas d'école, pas de papiers, pas de vie. Alors j'ai écrit le 10 — le dernier jour légal avant la fermeture.*
>
> *Et j'ai choisi le 10 pour une raison précise. Regardez la colonne « jour » du registre. Il fallait qu'elle reste vraie.*

Fenêtre : du 12 au 19. Colonne : vendredi. Mois : septembre. Année : 1999.
Les vendredis de septembre 1999 sont les **3, 10, 17 et 24**. Un seul tombe dans la fenêtre.

> # 17 septembre 1999

Il tape `17091999`. **Ce n'est pas un code qu'on lui donne, c'est une date qu'il vient de démontrer.**

### Et les trois anomalies s'expliquent en trois lignes

- **La sixième personne sur le cliché de 1999** : Adèle. Elle n'était pas de garde cette nuit-là. Elle est venue parce qu'on l'avait appelée.
- **L'encre disparue** : la règle n'était pas une superstition. Les copies du carton 47 étaient tirées à l'encre photosensible, pour qu'aucune ne survive à un jour de lumière. Quelqu'un, en 1999, avait déjà prévu qu'on chercherait.
- **La règle elle-même** : ce n'est pas Adèle qui l'a inventée. C'est Okoumé, en 2019, pour que le carton devienne impossible à traiter administrativement — donc impossible à détruire.

> Rien de surnaturel. Mais pendant six jours, **il ne pouvait pas le savoir** — et c'est exactement ce que fait FROM.

### Puis la fiction tombe

> *Adèle n'existe pas. Okoumé non plus. Ruth n'a jamais été renvoyée, et je m'excuse pour la nuit où tu l'as cru.*
> *Le carton 47 est vide, l'arrêté est faux, et le registre est de ma main.*
>
> *La seule chose vraie de toute cette affaire, c'est que tu es né un vendredi 17 septembre 1999, que la mairie s'est trompée de sept jours, et que quelqu'un a mis sept jours à te les rendre.*
>
> *Bon anniversaire, bébé.*
> *Ce soir. 17h00. Deux couverts.*

---

## Ce qui le fait revenir

Pas les énigmes — **le fait qu'aucune conviction de la veille ne tienne le lendemain.**

| Jour | Ce qu'il croit le soir | Ce qui est vrai |
|---|---|---|
| 10 | Une inconnue a besoin de lui | Elle le teste |
| 11 | Un homme la menace | Cet homme savait avant lui |
| 12 | Cet homme est dangereux | Il est le seul honnête |
| 13 | On le surveille de l'extérieur | Le canal est compromis |
| 14 | Il enquête | On enquête à travers lui |
| 15 | Il a démasqué l'ennemi | L'ennemi protégeait la coupable |
| 16 | Il cherche une coupable | Il l'avait au bout du fil depuis le premier soir |
| 17 | Il enquête sur une inconnue | C'est son propre acte de naissance |

Et par-dessus, trois fils qui n'ont pas de solution :
**la règle** qu'on ne lui explique jamais · **les sept symboles** que rien ne signale · **la sixième personne** sur une photo qui n'en compte que cinq.

---

## Les huit énigmes, inchangées

Solutions uniques déjà vérifiées par script. Elles se replacent une par une :

| Ch. | L'énigme | Rend |
|---|---|---|
| 1 | Sept dépositions, deux menteurs | `VENDREDI` |
| 2 | Le faux certificat | `1999` |
| 3 | Le carnet fermé | `SEPTEMBRE` |
| 4 | Les relevés maquillés | `DU 12 AU 19` |
| 5 | Cinq déclarations, un imposteur | un nom |
| 6 | Le scellé forcé | `561` |
| 7 | Qui tenait la clé | `04H10` |
| 8 | La convergence | `17091999` |

---

## À trancher

- [ ] **La sanction du chapitre 4 est-elle réelle ?** Si la pièce s'efface pour de bon, l'énigme devient plus dure sans retour possible. C'est ce qui donne du poids à la règle — et c'est réglable depuis l'admin
- [ ] **Ruth** — c'est le personnage qui coûte. Si tu ne veux pas de cette culpabilité dans un jeu d'anniversaire, on la garde et on la fait revenir au chapitre 8
- [ ] Le titre : `LE CARTON 47` / `LE REGISTRE` / `SAINTE-ODILE`
