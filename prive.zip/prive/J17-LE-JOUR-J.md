# Le 17 septembre — déroulé heure par heure

Contrainte de fond : **tout commence à 17h00** et tu dois pouvoir partir vers minuit. Le début tôt n'est pas un compromis, c'est un avantage — il laisse la soirée respirer au lieu de l'enchaîner.

---

## 06h00 — L'assemblage

Notification : **« Les six pièces sont descellées. »**

Il assemble les six tuiles, lit `17091999` en travers de l'image, entre le code.

> **ACTE DE NAISSANCE — RECTIFICATION**
> *La mention « 10 septembre 1999 » portée au registre est annulée.*
> *Il est rétabli que l'intéressé est né le* **17 SEPTEMBRE 1999**.
> *Dossier 1709/26 — affaire close. Vingt-sept ans, jour pour jour.*

Puis, en dessous, une enveloppe fermée :

> *Une pièce jointe est restée dans le dossier. Elle n'a rien à voir avec l'affaire.*

---

## 06h10 — L'énigme bonus

Courte : dix, quinze minutes avec son café. Elle ne sert qu'à ouvrir l'enveloppe.

> **Trois cartons de réservation ont été mélangés au dossier. L'un est à ton nom.**
>
> Les trois heures sont trois nombres impairs consécutifs dont la somme vaut 57.
> Les trois nombres de couverts sont trois nombres pairs consécutifs dont le produit vaut 48.
>
> 1. Le carton de quatre couverts est le plus tardif des trois.
> 2. Le carton de six couverts est réservé deux heures après celui de deux couverts.
> 3. Le carton de 19h n'est pas celui de quatre couverts.
> 4. Le tien n'est ni le plus tardif, ni le plus nombreux.
>
> **Quelle heure, combien de couverts ?**

**Solution — vérifiée, unique.** Les heures sont 17, 19, 21 ; les couverts 2, 4, 6. La clause 1 place les quatre couverts à 21h. Restent 2 et 6 pour 17h et 19h ; la clause 2 impose 2 à 17h et 6 à 19h. La clause 4 élimine 21h et 6 couverts : il ne reste que **17h00, deux couverts**.

Réponse attendue : `17h 2` (accepte `17h00 2 couverts`).

---

## 06h25 — L'invitation

Elle doit faire exactement trois choses : donner l'heure, imposer une tenue, et ne rien dire d'autre.

> ████████████████
> *Le nom de l'établissement ne figure pas sur ce carton.*
>
> **Jeudi 17 septembre — 17h00 — deux couverts**
>
> L'entrée du marché
> La pièce de la maison
> Le dessert
>
> *Le chef ne communique pas sa carte à l'avance.*
>
> **Tenue exigée.** L'établissement la fournit.
> **Présentez-vous à 16h30.** Aucun retard toléré.
>
> *Adresse communiquée le jour même.*

Trois mots de menu, aucun nom de plat. Il saura qu'il y a une entrée, un plat et un dessert — rien de plus. Le nom caviardé fait plus d'effet qu'un nom absent : il y a quelque chose à cacher, donc il y a quelque chose.

**« L'établissement la fournit »** est la phrase qui travaille pour toi toute la journée. Il ne peut pas s'habiller à l'avance, donc il doit rentrer, et il doit rentrer à l'heure.

---

## Dans la journée — deux relances programmées

**12h00 :**
> *Confirmation de réservation. Deux couverts, 17h00. Le vestiaire vous attend à 16h30.*

**16h05 :**
> *Votre tenue est prête. Elle ne vous attendra pas.*
> *Vous avez vingt-cinq minutes.*

Tu gardes ta posture jusqu'au bout : dans la journée, tu es celle qui insiste pour sortir, agacée par l'heure de la réservation. Ne lâche rien.

---

## 16h30 — L'arrivée

Il ouvre la porte et il voit tout d'un coup : la table dressée, la lumière, toi en tenue. C'est le moment de bascule, et il vaut mieux qu'il soit entier plutôt qu'étalé sur une demi-heure de mise en scène.

Tu lui donnes sa tenue. Il se change. Pendant ce temps tu allumes, tu lances la musique, tu poses la carte sur la table.

**Le nom de l'établissement, il ne le lit que sur le menu imprimé**, une fois assis. C'est le dernier mot de l'énigme et il arrive au bon moment — pas dans l'appli, sur le papier.

Trente minutes entre l'arrivée et le service : c'est court, et c'est bien. Il n'a pas le temps de retomber.

---

## La soirée

| Heure | Ce qui se passe |
|---|---|
| **17h00** | Il frappe. Tu ouvres. Accueil, on l'installe, photo à l'entrée comme dans un vrai resto |
| 17h15 | Le menu est présenté. C'est là qu'il lit enfin le nom de l'établissement |
| 17h30 | Entrée — la salade |
| 18h15 | Plat — l'eru |
| 19h00 | On desserre, musique, un peu de zouk parce que la maison l'exige |
| 19h30 | Dessert — le gâteau, les bougies |
| **20h00** | **L'addition** arrive sur son téléphone. Elle annonce les cadeaux |
| 20h00 – 21h30 | Les cadeaux, un par un, à son rythme |
| 21h30 – 23h00 | Photos souvenir, calme, ce que vous voulez |
| 23h00 | Rangement à deux, tu pars vers 23h30 |

Six heures et demie. Rien n'est serré, tu n'auras jamais à regarder l'heure, et la partie qui compte — les cadeaux — tombe à 20h, largement avant que la fatigue ne s'invite.

---

## 20h00 — L'addition et les cadeaux

**L'addition est imprimée**, comme le menu. Tu la poses sur la table à la fin du dessert. Elle ne réclame pas d'argent : elle annonce la suite.

> **L'ADDITION**
> *Table 1 — deux couverts — 17 septembre*
>
> Entrée .................................. néant
> Plat .................................... néant
> Dessert ................................. néant
> Service ................................. néant
>
> **TOTAL : néant.** *Réglé d'avance. Il y a un an et demi.*
>
> *L'établissement invite son client à consulter son dossier.*

Cette dernière ligne le renvoie à l'appli. L'écran **« EFFETS PERSONNELS »** s'y est ouvert : la liste des cadeaux, chacun en carte fermée, décrit en une ligne de vocabulaire administratif. Il tape, la carte se retourne, tu poses l'objet devant lui.

> **EFFETS PERSONNELS — RESTITUTION**
> *Dossier 1709/26 — scellés levés*
>
> ▸ Objet n°1 — petit matériel électronique .......... *sous scellé*
> ▸ Objet n°2 — petit matériel électronique .......... *sous scellé*
> ▸ Objet n°3 — article chaussant, pointure connue ... *sous scellé*
> ▸ Objet n°4 — portrait, format encadré ............. *sous scellé*
> ▸ Objet n°5 — portrait, second format .............. *sous scellé*

Le vocabulaire fait tout le travail : « petit matériel électronique » ne dit rien du gadget, et il aura envie de retourner la carte pour savoir lequel c'est.

**Garde les portraits pour la fin.** Les gadgets font rire et s'ouvrent vite ; un portrait de ses frères ne s'ouvre pas, il se regarde. Si tu le mets en premier, tout ce qui suit retombe.

Prévois un bouton discret côté admin pour retourner une carte toi-même : s'il s'emballe et veut tout ouvrir d'un coup, tu gardes la main sur le rythme.

**La septième pièce du puzzle** — celle qui manquait à l'image du matin — est posée sur son assiette avant l'entrée, face cachée. Il la retourne quand il veut. Elle porte : *« 27 ans, et enfin la bonne date. »*

---

## Ce qu'il faut préparer côté site

| Élément | Détail |
|---|---|
| Déblocage 06h00 | Les six tuiles ne sont servies qu'à cette heure-là. Rien avant, jamais |
| Énigme bonus | Une page, une réponse, dix minutes |
| Invitation | Nom caviardé (un vrai bloc noir, pas un blanc), menu en trois lignes évasives |
| Deux relances | 12h00 et 16h05, en push. Textes ci-dessus |
| Écran effets personnels | Ouverture à 20h00, cinq cartes retournables, bouton admin de secours |

---

## Ta checklist du 17

**Avant 16h30 :** table dressée, sa tenue prête à lui remettre, menu imprimé, addition imprimée, septième pièce sur l'assiette, cadeaux planqués mais accessibles, playlist prête, téléphone chargé.

**Les deux papiers comptent autant que l'appli.** Le menu et l'addition sont ce qu'il aura entre les mains pendant six heures — imprime-les sur du vrai papier épais, pas sur une feuille de bureau.
