# LE CARTON 47 — le dossier de conduite
### Les huit jours : intrigue, énigme, réponse, indices. Tout ce qui est en base.

> **Ce document contient toutes les réponses.** Il vit dans `prive/`, hors du dépôt git.

---

## Comment marchent les indices

**Il doit les demander.** Rien ne s'affiche tout seul.

1. Il ouvre la manche → le chrono part
2. Au bout du premier palier, un bouton **« Demander un indice »** s'active
3. Tant qu'il ne clique pas, **le texte de l'indice n'a jamais quitté le serveur** — il n'est ni dans la page, ni dans l'onglet réseau
4. Chaque indice demandé reste affiché, et le suivant attend son propre palier

S'il demande trop tôt, le site répond combien de minutes il reste. C'est tout.

### Ce que tu règles depuis `/admin → Les règles`

**Les paliers**, une valeur par ligne, en minutes depuis l'ouverture de la manche :

```
60
120
180
```

Trois lignes = trois indices demandables, à 1h, 2h et 3h. Mets `20 / 45 / 90` s'il bloque, ou `5 / 10 / 15` pour tes propres essais. Le nombre de lignes n'a pas besoin de correspondre au nombre d'indices écrits : le site prend le plus petit des deux.

> **Pourquoi depuis l'ouverture et pas depuis l'aube :** s'il ouvre la manche à 21h, ses indices s'ouvrent à 22h, 23h et minuit. Comptés depuis 6h du matin, ils seraient tous déjà disponibles avant qu'il ait lu l'énoncé.

---

# JOUR 1 · mercredi 10 septembre
## Le parapluie de la voiture 3

### L'intrigue

**23h47.** Un numéro inconnu.

> *Bonsoir. Vous ne me connaissez pas.*
>
> *Je m'appelle Adèle Mbeng, archiviste à la mairie centrale. Depuis six mois je numérise les registres de naissance de 1999. Il y a un acte, dans le carton 47, qui n'aurait jamais dû être écrit.*
>
> *Je ne peux en parler à personne ici, et je ne peux pas vous envoyer le document : les sorties de fichiers sont journalisées, je serais repérée en une heure. Je vais devoir vous le faire passer en morceaux, cachés dans des choses sans intérêt.*
>
> *Avant, je dois savoir si vous en êtes capable. Il y a un vieux dossier de 1994 dans le même carton. Sept voisins, deux menteurs. Personne ne l'a jamais résolu.*
>
> *Faites-le et je continue.*

**Post-scriptum, sans explication :**

> *Trois choses, et ne me demandez pas pourquoi.*
> *Le carton 47 ne se consulte qu'entre le coucher et le lever du soleil.*
> *Ce qui en sort la nuit doit y être rentré avant l'aube.*
> *On n'écrit jamais dans le registre. On recopie à côté.*

### L'énigme

> **DOSSIER 1 · classé le 4 mars 1994**
> Sept dépositions recueillies au 12 de la rue Ndjolé.
>
> Un locataire du troisième a quitté l'immeuble un jour de la semaine dernière, et n'y est pas revenu. Sept voisins ont été entendus. Le rapport ne conclut rien, sauf une ligne, soulignée deux fois :
>
> **« Exactement deux de ces sept personnes mentent. »**
>
> **1 · Mme ONDO** — fiche F-1041
> *« C'était un jour de passage du camion. »* — le camion passe le mardi et le vendredi
>
> **2 · M. BALEP** — fiche F-1042
> *« C'était le lendemain du jour où j'ai touché ma paie. »* — payé chaque jeudi
>
> **3 · LA BOULANGÈRE** — fiche F-1043
> *« Ma boutique était ouverte, il est passé devant. »* — fermée le lundi et le dimanche
>
> **4 · LE GARDIEN** — fiche F-5017
> *« C'était deux jours après le marché. »* — marché le jeudi
>
> **5 · SŒUR MVÉ** — fiche F-1045
> *« Au moins un des deux, Ondo ou Balep, ment. »*
>
> **6 · M. TCHOUA** — fiche F-1046
> *« C'était un jour ouvré. »*
>
> **7 · AWA** — fiche F-1047
> *« Ce n'était ni un mardi ni un mercredi. »*
>
> **Quel jour, et qui sont les deux menteurs ?**

### La réponse

**`VENDREDI`, menteurs n° 4 (le gardien) et n° 5 (Sœur Mvé).**

*Solution unique vérifiée par force brute sur les 147 combinaisons — 7 jours × 21 paires. Aucune autre ne survit.*

**Le raisonnement.** Si le gardien dit vrai, c'est samedi : Ondo, Balep, Mvé et Tchoua deviennent tous menteurs d'un coup. Quatre, alors qu'il n'en faut que deux. Le gardien ment. Reste vendredi, où Ondo, Balep, la boulangère, Tchoua et Awa disent tous vrai — donc Mvé, qui affirme que l'un des deux premiers ment, est le second menteur.

**Le piège :** le gardien est le seul témoin qui donne une date précise. C'est exactement pour ça qu'on le croit.

**Formulations acceptées** — 36 au total, générées : `vendredi 4 5`, `vendredi 5 4`, `vendredi 4 et 5`, `4 5 vendredi`, `le vendredi 4 5`, et les variantes par nom : `vendredi gardien mve`, `vendredi le gardien et sœur mvé`, `vendredi mve et gardien`…

### Les trois indices

1. *Sept jours, vingt et une paires de menteurs possibles : cent quarante-sept combinaisons. C'est peu. Rien n'interdit de les parcourir une à une.*
2. *La cinquième déposition ne parle pas du jour. Elle parle des autres dépositions. Traite-la à part : elle peut être fausse sans qu'aucune de celles qu'elle vise le soit.*
3. *Suppose un instant que le gardien dise vrai, et compte combien de personnes deviennent menteuses. Tu verras que c'est beaucoup trop.*

### L'anomalie · *rien ne la signale*

**Où :** les numéros de fiche.
**Ce qui se dépose au tableau :** *La fiche du gardien porte le numéro F-5017. Les six autres se suivent — F-1041, 1042, 1043, puis 1045, 1046, 1047. Il manque F-1044, et le gardien occupe sa place avec un numéro venu d'ailleurs.*
**Accepté :** `F-5017`, `5017`, `la fiche du gardien`, `numéro de fiche`, `F-1044`, `il manque F-1044`

---

# JOUR 2 · jeudi 11 septembre
## Le masque au certificat

### L'intrigue

Adèle envoie la pièce dans la matinée.

> *Apprenez à ne pas croire un papier tamponné. Vous en verrez d'autres.*

**04h12.** Un second numéro. Minuscules, pas de ponctuation.

> `n'ouvrez pas ce qu'elle vous envoie`

Il montre le message à Adèle. Elle met vingt minutes à répondre — ce qui ne lui ressemble pas.

> *Il s'appelle Okoumé. Il était greffier ici. On l'a radié en 2019.*
> *Ne lui répondez pas. Et surtout ne lui dites pas où vous en êtes.*

**09h30.** Un troisième message. Ruth, 23 ans, stagiaire à la numérisation. Elle a vu son nom passer dans le journal des consultations.

> *bonjour !! excusez moi de vous deranger comme ça 😅 jai vu votre nom dans le journal des consultations du fonds 47 et personne ne consulte jamais ce fonds. si vous cherchez quelque chose jai acces au scanner moi. dites moi je peux aider*

> **Premier retournement, et il ne le voit pas :** personne n'a dit à Okoumé qu'Adèle lui écrivait.

### L'énigme

> **DOSSIER 2 · saisie du 9 novembre 2001**
>
> Un masque, vendu comme pièce ancienne, avec un certificat d'authenticité en bonne et due forme :
> **« Pièce sculptée en 1974. Certifiée conforme. »**
>
> Saisi le même jour, chez le même homme : son registre d'atelier. Trois entrées portent une date lisible.
>
> ```
> n° 060 — mars 1994
> n° 300 — mars 1996
> n° 540 — mars 1998
> ```
>
> L'atelier a été déclaré à la préfecture le 2 février 1994.
> Le masque porte, gravé sous la mâchoire, le numéro **726**.
>
> **En quelle année a-t-il réellement été fabriqué ?**

### La réponse

**`1999`**

240 numéros en deux ans, soit **120 par an**. Du n° 60 en mars 1994 au n° 726 : (726 − 60) ÷ 120 = **5,55 ans**, soit octobre 1999.

**Le double fond :** le certificat annonce 1974 — vingt ans avant l'ouverture de l'atelier. Il n'est pas seulement faux, il a été fabriqué par la même main que le masque.

**Accepté :** `1999`

### Les trois indices

1. *Les trois entrées datées suffisent à établir un rythme. Combien de numéros par an ?*
2. *Cent vingt numéros par an, à partir du n° 60 en mars 1994. Où tombe le 726 ?*
3. *(726 − 60) ÷ 120 = 5,55 ans après mars 1994.*

### L'anomalie

**Où :** la date du certificat, comparée à la déclaration en préfecture.
**Texte :** *Le certificat date la pièce de 1974 — vingt ans avant l'ouverture de l'atelier. Le certificat n'est pas seulement faux : il a été fabriqué par la même main que le masque.*
**Accepté :** `le certificat`, `1974`, `l'atelier n'existait pas`, `atelier ouvert en 1994`

---

# JOUR 3 · vendredi 12 septembre
## Le carnet fermé

### L'intrigue

Adèle n'écrit pas de la journée.

**Okoumé envoie la pièce à sa place — et elle est mieux préparée que celles d'Adèle.**

> `un carnet qui ne s'ouvre pas est un carnet qui attend qu'on le lui demande correctement`
> `je suppose que vous savez comment on demande poliment à un parchemin`
> `elle vous ment sur un point. un seul. je ne vous dirai pas lequel, vous ne me croiriez pas et vous auriez raison`

**Le soir, Ruth :**

> *jai retrouvé le cliché de 1999 dans le carton !! il y a 6 personnes dessus mais le registre de garde en liste 5 😭*

> **Première anomalie du récit.** Personne n'expliquera jamais qui est la sixième — jusqu'au dernier jour.

### L'énigme — en trois actes

**Acte 1 · la serrure.** Une page vierge. *« Ce carnet ne s'ouvre pas. Il faut le lui demander correctement. »*

La phrase de passe : **« Je jure solennellement que mes intentions sont mauvaises »**
L'encre apparaît alors ligne à ligne. **`Méfait accompli`** referme le parchemin.

**Acte 2 · le chiffre.** Ce qui apparaît n'est pas un texte :

```
XE DOCV UOV VE THYUGBV QSK CYOYC FG
LR BUOEHTQ SLCWHHY R XA MIYUKY VF OL
LYV IHWMNKS LHTLVZNVNN OI WYQMZN XH P YTALV
```

**Le piège :** il va lancer une analyse de fréquences, comme la veille. **Elle ne donnera rien** — la lettre la plus fréquente plafonne à 9,7 %, là où un E français en pèse 15. Ce n'est pas une substitution : c'est un **Vigenère**. Il lui faut Kasiski, ou la clé.

**La clé est `MARAUDEUR`** — le mot qu'on vient de lui mettre entre les mains.

**Acte 3 · la devinette.** Déchiffré :

> *« Le mois que je cherche est celui où la Balance succède à la Vierge, et où les enfants reprennent le chemin de l'école. »*

**Le mois n'est jamais écrit.** Il faut savoir que la Vierge cède à la Balance vers le 23, et que la rentrée est en septembre. Deux indices indépendants qui se recoupent sur un seul mois.

### La réponse

**`SEPTEMBRE`** — accepté : `septembre`, `le mois de septembre`, `sept`

### Les trois indices

1. *L'analyse de fréquences ne donnera rien : la lettre la plus fréquente plafonne à 9,7 %, là où un E français en pèse 15. Ce n'est pas une substitution simple.*
2. *Cherche les groupes de lettres qui se répètent et mesure les distances entre eux. Kasiski, 1863. La clé a neuf lettres.*
3. *La clé est le mot que tu as lu aujourd'hui sans y prêter attention : MARAUDEUR.*

### L'anomalie

**Où :** sous le texte déchiffré, une ligne d'une autre encre.
**Texte :** *« Si tu lis ceci, c'est que tu as ma clé. Alors tu sais déjà que je n'ai jamais résolu ces affaires. » L'Archiviste n'écrit pas au lecteur. Il écrit à quelqu'un d'autre.*
**Accepté :** `une autre encre`, `la dernière ligne`, `il écrit à quelqu'un`, `autre écriture`

---

# JOUR 4 · samedi 13 septembre
## Le wagon qui n'a pas roulé

### L'intrigue

Il remonte le fil de la veille et trouve **un horodatage sans message**. Adèle a écrit le 12 à 09h04. Supprimé avant qu'il l'ouvre.

> **Deuxième retournement.** Ce n'est pas une surveillance extérieure. Quelqu'un a la main sur le canal lui-même.

**Balep**, le vigile de nuit, lui propose un marché : il peut photographier le carton pendant sa ronde, contre un service.

**Et c'est le soir où il garde une pièce trop longtemps.** Au matin, elle est vierge. L'encre a disparu.

> **Deuxième anomalie.** Aucune explication rationnelle, et personne ne lui en propose.
> *(Réglable : tu décides si la sanction est réelle — l'énigme devient plus dure — ou seulement racontée.)*

### L'énigme

> **DOSSIER 4 · relevés du compteur général**
>
> Le bâtiment est réputé avoir fonctionné sans interruption tout le mois. Index relevé chaque soir, en kWh :
>
> ```
>  1 → 48377     11 → 49201     21 → 50250
>  2 → 48514     12 → 49297     22 → 50382
>  3 → 48682     13 → 49394     23 → 50457
>  4 → 48747     14 → 49490     24 → 50616
>  5 → 48783     15 → 49587     25 → 50675
>  6 → 48815     16 → 49683     26 → 50753
>  7 → 48834     17 → 49780     27 → 50857
>  8 → 48853     18 → 49876     28 → 50924
>  9 → 48996     19 → 49973     29 → 51086
> 10 → 49125     20 → 50096     30 → 51160
> ```
>
> Une note au dossier signale une fermeture administrative **du 5 au 8** : congé collectif, déclaré, régulier.
>
> **Trouve les jours où le bâtiment ne fonctionnait pas — et qu'on a voulu cacher.**

### La réponse

**`DU 12 AU 19`** — huit jours.

**Le double fond.** Le creux du 5 au 8 saute aux yeux : moyenne 26 kWh/jour contre 115 ailleurs. Il est réel, il est déclaré, **et ce n'est pas la réponse.**

La vraie période a une moyenne **parfaitement normale — 96 kWh/jour** — mais un écart-type de **0,5** là où le reste du mois vaut **38,9**. Les écarts alternent 96, 97, 96, 97 : la signature d'un générateur, pas d'un bâtiment.

**Accepté :** `12 19`, `du 12 au 19`, `12 au 19`, `12-19`, `du 12 septembre au 19 septembre`

### Les trois indices

1. *Un index ne dit rien. Ce sont les écarts d'un jour à l'autre qu'il faut regarder.*
2. *Le creux du 5 au 8 est réel et déclaré : ce n'est pas lui. Cherche une période dont la moyenne est parfaitement normale.*
3. *Calcule l'écart-type des écarts journaliers, par tranches. Ailleurs il vaut environ 39. Sur huit jours consécutifs, il tombe à 0,5. Un compteur réel ne respire jamais aussi régulièrement.*

### L'anomalie

**Où :** les écarts de la période maquillée, un par un.
**Texte :** *Les écarts fabriqués alternent 96, 97, 96, 97 — la signature d'un générateur, pas d'un bâtiment. Celui qui a maquillé ces relevés savait quelle moyenne imiter, mais pas qu'il fallait aussi imiter le désordre.*
**Accepté :** `96 97`, `ils alternent`, `l'alternance`, `trop régulier`, `un générateur`

---

# JOUR 5 · dimanche 14 septembre
## Cinq voyageurs

### L'intrigue

Adèle revient. Froide.

> *Pourquoi lui avez-vous parlé du carton 47 ?*
> *Je ne l'avais dit qu'à vous.*

Il n'a rien dit. Il n'a jamais répondu à Okoumé. Ils comparent, et comprennent.

> **Troisième retournement.** Depuis trois jours, **Okoumé écrit à Adèle en se faisant passer pour lui.** Deux conversations existent, une seule est vraie. Il n'a pas seulement été surveillé — il a été *employé* : tout ce qu'il trouvait, Okoumé le recevait le soir même, signé de son nom.

**Et Ruth ne répond plus.** Son dernier message datait de 23h14, la veille :

> *attends je crois quil y a quelquun*

### L'énigme

> **DOSSIER 5 · cinq dépositions**
>
> Cinq personnes déclarent avoir participé à la même mission de relevé, une nuit de septembre. Quatre y étaient. **La cinquième a appris son rôle.**
>
> **1 · MENGUE** — *« On est partis à quatre heures dix. Il pleuvait sur la route du bas. J'ai porté la caisse verte, celle dont la poignée était cassée. Le gardien nous a ouvert sans rien demander. Je crois qu'il s'appelait Ondo, ou Ondja. »*
>
> **2 · BEKALE** — *« Quatre heures et quelques. La route du bas était impraticable, on a pris l'autre. J'avais oublié mes gants, Mengue m'a prêté les siens. Le portail était déjà ouvert quand on est arrivés. »*
>
> **3 · NZE** — *« Le départ était à quatre heures dix. Enfin, quatre heures et demie, je ne sais plus. Il pleuvait. La caisse verte pesait une tonne. J'ai laissé tomber un projecteur et personne ne m'a rien dit, ce qui m'a surpris. »*
>
> **4 · OYONO** — *« Quatre heures dix, il pleuvait, on a pris la route du bas, Mengue portait la caisse verte à la poignée cassée, et le gardien a ouvert sans rien demander. »*
>
> **5 · ABESSOLO** — *« Je me souviens surtout du froid. On a attendu vingt minutes devant le portail que quelqu'un retrouve la clé. Bekale jurait dans le noir. Je n'ai vu la caisse verte qu'au retour. »*
>
> **Laquelle de ces cinq personnes n'y était pas ?**

### La réponse

**`OYONO`** — la quatrième.

**Le double fond, et c'est le meilleur du jeu.** Nze se contredit ouvertement — quatre heures dix, puis quatre heures et demie. C'est le suspect désigné, **et il est innocent** : un vrai souvenir est imparfait, c'est sa signature.

Le critère est l'inverse de l'intuition. Les quatre vrais témoignages **apportent chacun une information que personne d'autre ne donne** : le nom approximatif du gardien, les gants prêtés, le projecteur tombé, les vingt minutes d'attente. Oyono n'apporte **rien qui ne soit déjà déductible des quatre autres**. Il a lu leurs déclarations avant d'écrire la sienne.

C'est un critère d'**information**, pas de cohérence.

**Accepté :** `oyono`, `la quatrième`, `4`, `quatre`

### Les trois indices

1. *Un vrai souvenir est imparfait. Celui qui se contredit se souvient mal — ce n'est pas la même chose que mentir.*
2. *Compare ce que chaque déposition APPORTE. Quatre d'entre elles contiennent au moins un détail que personne d'autre ne donne.*
3. *Une seule déposition ne contient rien qui ne soit déjà dans les autres. Elle n'a pas été vécue, elle a été lue.*

### L'anomalie

**Où :** le message d'Adèle de ce jour-là, comparé à sa conclusion.
**Texte :** *Adèle désigne Nze avec assurance, et elle se trompe. Ce n'est pas une erreur : Nze est la seule des cinq qui aurait pu la contredire.*
**Accepté :** `elle se trompe`, `adèle se trompe`, `le message est faux`, `nze`, `elle ment`

---

# JOUR 6 · lundi 15 septembre
## Le scellé forcé

### L'intrigue

Il ne demande plus la permission. Il force le scellé et remonte au dossier personnel d'Okoumé.

> **CONSEIL DE DISCIPLINE — 2019**
> *M. Okoumé, greffier, radié pour refus caractérisé d'exécuter l'ordre de destruction du carton 47.*

Il relit trois fois.

> **Quatrième retournement.** Okoumé n'a jamais voulu détruire le dossier. Il a été radié pour avoir **refusé** de le faire. Depuis six ans, il empêche qu'on l'ouvre — non pour se couvrir, mais pour couvrir quelqu'un d'autre.

**Puis Mme Ondo, en-tête officiel, deux lignes :**

> *Mlle Ruth Ekomi a été mise à pied à titre conservatoire le 14 septembre, à la suite d'un accès non autorisé au fonds 47. Nous vous saurions gré de cesser toute sollicitation.*

**C'est lui qui lui avait demandé de scanner le cliché.**

**Et Balep, le même soir :** *« la dame m'a demandé qui venait la nuit. j'ai dit. désolé chef. »*

> **Ce jour-là il ne perd pas une manche. Il perd quelqu'un** — renvoyée à 23 ans pour l'avoir aidé, sans aucun moyen de réparer.

**Okoumé, 03h50 :**

> `vous êtes allé trop loin maintenant`
> `si vous vous arrêtez là ils reprendront le dossier et le brûleront et elle sera tranquille`
> `si vous continuez vous la trouverez`
> `je ne vous aiderai plus mais je ne vous empêcherai plus`
> `choisissez vite il reste deux jours`

**Elle.**

### L'énigme

> **DOSSIER 6 · scellé numérique**
>
> Une photographie versée au dossier. On n'en a gardé que les métadonnées :
>
> ```
> Artist            : C. NZE
> DateTimeOriginal  : 1999:09:10 08:12:44
> ImageDescription  : 4e4545524752203536312051482031302046524347525a4f4552
> ```
>
> Sur la chemise : *« La clé est dans l'image, pas sur l'image. »*
>
> **Le numéro du document ?**

### La réponse

**`561`**

L'hexadécimal donne `NEERGR 561 QH 10 FRCGRZOER`. Décalé de treize lettres — ROT13 — cela devient **`ARRETE 561 DU 10 SEPTEMBRE`**.

**Le double fond :** le champ `Artist` porte un nom en clair. C'est un leurre — et c'est le nom qu'Adèle accusait la veille.

**Accepté :** `561`, `arrete 561`, `l'arrêté 561`, `arrêté n° 561`

### Les trois indices

1. *Le champ Artist est un nom. Un nom n'est pas une clé — et celui-là, tu l'as déjà vu hier.*
2. *ImageDescription est de l'hexadécimal. Convertis-le en texte : tu obtiendras quelque chose de lisible mais faux.*
3. *Ce que tu obtiens est décalé de treize lettres. ROT13.*

### L'anomalie

**Où :** le champ Artist.
**Texte :** *Le leurre porte le nom qu'Adèle accusait la veille. Elle n'a pas seulement désigné le mauvais coupable : elle avait préparé la pièce qui devait le confirmer.*
**Accepté :** `artist`, `le champ artist`, `c nze`, `nze`, `le leurre`

---

# JOUR 7 · mardi 16 septembre
## Qui tenait la clé

### L'intrigue

Il ne reste qu'une question : qui, la nuit du 16 au 17 septembre 1999, pouvait écrire dans le registre.

### L'énigme

> **DOSSIER 7 · le registre de garde**
>
> Cinq personnes se sont relayées cette nuit-là, une par créneau de vingt minutes, de 03h30 à 05h10. Une seule détenait la clé du registre.
>
> **MENGUE · BEKALE · NZE · OYONO · ABESSOLO**
> **03h30 · 03h50 · 04h10 · 04h30 · 04h50**
>
> 1. Abessolo a pris le premier créneau ou le dernier.
> 2. Bekale est arrivé exactement quarante minutes après Mengue.
> 3. Nze n'a jamais eu la clé.
> 4. La personne qui détenait la clé n'était ni la première ni la dernière.
> 5. Oyono a précédé Nze, mais pas immédiatement.
> 6. Mengue n'était pas là à 03h30.
> 7. Le registre a été ouvert pendant le créneau de celui qui détenait la clé.
> 8. Abessolo ne détenait pas la clé.
> 9. Bekale a pris le dernier créneau de la nuit.
> 10. Celui qui détenait la clé a pris son créneau après Oyono.
>
> **À quelle heure exactement le registre a-t-il été ouvert ?**

### La réponse

**`04H10`**

| 03h30 | 03h50 | 04h10 | 04h30 | 04h50 |
|---|---|---|---|---|
| ABESSOLO | OYONO | **MENGUE** *(la clé)* | NZE | BEKALE |

*Solution unique vérifiée par énumération des 120 permutations.*

**Le chemin :** la 9 fixe Bekale à 04h50, la 2 fixe Mengue à 04h10. Abessolo ne peut plus qu'être à 03h30 par la 1. Restent Oyono et Nze pour 03h50 et 04h30, et la 5 tranche. Pour la clé : ni Nze (3), ni Abessolo (8), ni les extrêmes (4), et après Oyono (10). Il ne reste que Mengue.

**Sans la dixième contrainte la grille a deux solutions.** Elle a été ajoutée après vérification.

**Accepté :** `04h10`, `4h10`, `04:10`, `4:10`, `quatre heures dix`

### Les trois indices

1. *Commence par Bekale : la neuvième contrainte le fixe, et la deuxième fixe alors Mengue.*
2. *Abessolo ne peut plus qu'être au premier créneau. Restent Nze et Oyono pour deux places.*
3. *La clé n'est ni au premier ni au dernier créneau, ni chez Nze, ni chez Abessolo, et elle est après Oyono. Il ne reste qu'une personne.*

### Puis le cinquième retournement

> **ADÈLE MBENG** tenait la clé du registre en 1999.
>
> Elle n'a pas découvert cet acte il y a six mois en numérisant. **Elle l'a écrit il y a vingt-sept ans.** Elle a passé six mois à chercher quelqu'un capable de remonter jusqu'à elle — parce qu'une confession, on la croit ou on ne la croit pas ; une preuve, non.

> *Oui. Je vous ai fait travailler six jours pour arriver à moi. C'était le seul moyen que ça compte.*
> *Pour Ruth, je suis désolée. Je ne pensais pas qu'elle irait aussi vite.*

**Et les sept symboles s'alignent** — ce ne sont pas des numéros d'archivage, c'est une date gravée à l'envers.

### L'anomalie

**Où :** les cinq noms, comparés à ceux du dossier 5.
**Texte :** *Ce sont les cinq mêmes personnes qu'au dossier 5, dans une affaire censée n'avoir aucun rapport. Deux dossiers du fonds partagent leurs témoins.*
**Accepté :** `les mêmes noms`, `ce sont les mêmes`, `dossier 5`, `les mêmes témoins`

---

# JOUR 8 · mercredi 17 septembre, 06h00
## La convergence

### L'intrigue

> *La maternité Sainte-Odile a été fermée par arrêté n° 561, du 12 au 19 septembre 1999. Huit jours. Un bâtiment administrativement mort.*
>
> *Un enfant y est né quand même. Je l'ai mis au monde moi-même, il n'y avait personne d'autre.*
>
> *Un enfant sans déclaration n'a pas de nom. Pas d'école, pas de papiers, pas de vie. Alors j'ai écrit le 10 — le dernier jour légal avant la fermeture.*
>
> *Et j'ai choisi le 10 pour une raison précise. Regardez la colonne « jour » du registre. Il fallait qu'elle reste vraie.*

### L'énigme

Ses sept résultats s'alignent :

| Dossier 1 | **VENDREDI** |
| Dossier 2 | **1999** |
| Dossier 3 | **SEPTEMBRE** |
| Dossier 4 | **DU 12 AU 19** |
| Dossier 5 | OYONO |
| Dossier 6 | **561** |
| Dossier 7 | 04H10 |

**Un vendredi. En septembre 1999. Entre le 12 et le 19.**

### La réponse

Les vendredis de septembre 1999 sont les **3, 10, 17 et 24**. Un seul tombe dans la fenêtre.

# `17091999`

**Ce n'est pas un code qu'on lui donne — c'est une date qu'il vient de démontrer.**

**Accepté :** `17091999`, `17 09 1999`, `17/09/1999`, `17-09-1999`

### Les deux indices

1. *Les vendredis de septembre 1999 sont les 3, 10, 17 et 24.*
2. *Un seul tombe entre le 12 et le 19.*

### Les trois anomalies s'expliquent

- **La sixième personne sur le cliché de 1999** : Adèle. Elle n'était pas de garde cette nuit-là. Elle est venue parce qu'on l'avait appelée.
- **L'encre disparue** : la règle n'était pas une superstition. Les copies du carton 47 étaient tirées à l'encre photosensible, pour qu'aucune ne survive à un jour de lumière. Quelqu'un, en 1999, avait déjà prévu qu'on chercherait.
- **La règle elle-même** : ce n'est pas Adèle qui l'a inventée. C'est Okoumé, en 2019, pour que le carton devienne impossible à traiter administrativement — donc impossible à détruire.

*Rien de surnaturel. Mais pendant six jours, il ne pouvait pas le savoir.*

### Puis la fiction tombe

> *Adèle n'existe pas. Okoumé non plus. Ruth n'a jamais été renvoyée, et je m'excuse pour la nuit où tu l'as cru.*
> *Le carton 47 est vide, l'arrêté est faux, et le registre est de ma main.*
>
> *La seule chose vraie de toute cette affaire, c'est que tu es né un vendredi 17 septembre 1999, que la mairie s'est trompée de sept jours, et que quelqu'un a mis sept jours à te les rendre.*
>
> *Bon anniversaire, bébé.*
> *Ce soir. 17h00. Deux couverts.*

---

## Le tableau de bord

| Jour | Manche | Réponse | Chrono réf. | Indices |
|---|---|---|---|---|
| 10 | Le parapluie de la voiture 3 | `VENDREDI` + n° 4 et 5 | 35 min | 3 |
| 11 | Le masque au certificat | `1999` | 55 min | 3 |
| 12 | Le carnet fermé | `SEPTEMBRE` | 75 min | 3 |
| 13 | Le wagon qui n'a pas roulé | `DU 12 AU 19` | 55 min | 3 |
| 14 | Cinq voyageurs | `OYONO` | 50 min | 3 |
| 15 | Le scellé forcé | `561` | 70 min | 3 |
| 16 | Qui tenait la clé | `04H10` | 60 min | 3 |
| 17 | La convergence | `17091999` | — | 2 |

**Ce qui t'attend dans `/admin` :** les huit récompenses sont vides. Les jours 2 et 5 portent le drapeau *gag* — ce sont les deux qui doivent décevoir.
